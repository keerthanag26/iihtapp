package com.tweetapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TweetReplyRequest {
	
	private String username;
	private int tweetId;
	private String tweetReply;
	public TweetReplyRequest(String username, int tweetId, String tweetReply) {
		super();
		this.username = username;
		this.tweetId = tweetId;
		this.tweetReply = tweetReply;
	}
	public TweetReplyRequest() {
	}
	

}
