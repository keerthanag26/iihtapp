package com.tweetapp.dto;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class TweetLoginRequestTest {

	private TweetLoginRequest tweetLoginRequest;

	@BeforeEach
	void before() {
		tweetLoginRequest = new TweetLoginRequest();
		tweetLoginRequest.setUsername("test-u1");
		tweetLoginRequest.setPassword("test-pass");
	}

	@Test
	void testParamaterizedConstructor() {
		TweetLoginRequest tweetLoginRequest=new TweetLoginRequest("user1", "password1");
		assertNotNull(tweetLoginRequest);
	}

	@Test
	void testGetUsername() {
		assertEquals("test-u1", tweetLoginRequest.getUsername());
	}

	@Test
	void testGetPassword() {
		assertEquals("test-pass", tweetLoginRequest.getPassword());
	}
}
