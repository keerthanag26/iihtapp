//package com.tweetapp.service;
//
//import static org.mockito.Mockito.mock;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//@ExtendWith(MockitoExtension.class)
//class KafkaProducerServiceTest {
//	
//	@InjectMocks
//	KafkaProducerService kafkaProducer;
//
//	@Test
//	void testSendMessage() {
//		KafkaProducerService kafkaProducerService = mock(KafkaProducerService.class);
//		//doNothing().when(kafkaProducerService).sendMessage("tweet_app");
//		kafkaProducer.sendMessage("tweet_app");
//		//verify(kafkaProducer,times(1)).sendMessage("tweet_app");
//	}
//
//}
