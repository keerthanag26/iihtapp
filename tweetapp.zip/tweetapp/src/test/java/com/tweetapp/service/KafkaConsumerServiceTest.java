//package com.tweetapp.service;
//
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.mock;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.junit.jupiter.MockitoExtension;
//@ExtendWith(MockitoExtension.class)
//class KafkaConsumerServiceTest {
//	@InjectMocks
//	KafkaConsumerService kafkaConsumer;
//
//	@Test
//	void testConsumeMessage() {
//		KafkaConsumerService kafkaConsumerService = mock(KafkaConsumerService.class);
//		doNothing().when(kafkaConsumerService).consume("Message received");
//		kafkaConsumer.consume("Message received");
//		//verify(kafkaConsumer,times(1)).consume("Message received");
//	}
//
//}
